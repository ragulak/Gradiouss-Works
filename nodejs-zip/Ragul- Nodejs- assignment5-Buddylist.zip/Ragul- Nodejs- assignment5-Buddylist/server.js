let express=require("express");
let fs=require("fs");
let app=express();
app.use(express.static("./public"));
var jsondata=[];
app.listen(8080);

app.use(express.json());
function readData(){
    jsondata=JSON.parse(fs.readFileSync("./data/buddy-list.json"));
}
// function writeData(){

//          fs.writeFileSync("./data/buddy-list.json",jsondata);
// }
app.get("/buddylist",(req,res)=>{
            readData();
            res.end(JSON.stringify(jsondata));

          
        }

);


app.post("/buddylist",(req,res)=>{ 
    readData();
    addedData=req.body;

    jsondata.push(addedData);
    
    fs.writeFile("./data/buddy-list.json",JSON.stringify(jsondata),(err)=>{
        if(err){

        console.log(err);
        }
        else{
            res.status(200).send("Success");
            console.log(jsondata);
        }
    });
    });

app.delete("/buddylist/:id",(req,res)=>{
let deleteid=req.params.id;
readData();
// let deleteindex=jsondata.findIndex((obj)=>obj.userId==deleteid);
   
    // delete jsondata[deleteindex];
    jsondata.splice(deleteid,1);
  fs.writeFile("./data/buddy-list.json",JSON.stringify(jsondata),(err)=>{
      if(err){
          console.log(err);
      }
      else{
          res.status(200).send("Deleted Successfully");
        //   console.log("deleted");
      }

  });

});

app.put("/buddylist/:id",(req,res)=>{

    var updateid=req.params.id;
    var updatedData=req.body;
    // console.log(updatedData);
    let indf = jsondata.findIndex((obj)=>obj.userId==updateid);
    // console.log(indf);
    jsondata[indf]=updatedData;
    fs.writeFile("./data/buddy-list.json",JSON.stringify(jsondata),(err)=>{
        if(err){
            console.log(err);
        }
        else{
            res.status(200).send("Updated Successfully");
        }
    });

});
