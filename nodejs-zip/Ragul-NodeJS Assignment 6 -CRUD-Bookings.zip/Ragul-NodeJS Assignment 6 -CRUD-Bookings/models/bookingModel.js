// id, customer_name, booking_date, booking_time, total_amount, status, payment_method, duration_minutes
const mongoose=require("mongoose");
const bookingSchema=mongoose.Schema({

    customer_name:{
        type:String,
        unique:true,
        trim:true,
        required:[true,"Name is required"],
    },

    
    
    booking_date:{
        type:String,
        trim:true,
        required:[true,"Booking_Date is required"],
        
    },
    
    
    booking_time:{
        type:String,
        trim:true,
        required:[true,"Booking_time is required"],
    },

    total_amount:{
        type:Number,
        trim:true,
        required:[true,"TotalAmount is required"],
    },

    status:{
        type:String,
        trim:true,
        required:[true,"Status is required"],
    },
    payment_method:{
        type:String,
        trim:true,
        required:[true,"PaymentMethod is required"],
    },
    duration_minutes:{
        type:String,
        trim:true,
        required:[true,"Duration_minutes is required"],
    },

    __v: { type: Number, select: false},
});


module.exports=mongoose.model("Bookings",bookingSchema); 
