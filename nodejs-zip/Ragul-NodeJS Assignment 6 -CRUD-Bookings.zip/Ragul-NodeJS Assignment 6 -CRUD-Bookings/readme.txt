
                                              Folder Name: Ragul-NodeJS Assignment 6 - Bookings

Database used: mongoDB
step 1 : Extract the zip folder
step 2 : Go to "Ragul-NodeJS Assignment 6 - Bookings"path directory and open CMD
step 3 : Excute the following commands
          3.1. "npm i"
          3.2. open the config file and update the credentials, database name and port number.
          3.3. "npm start" 
step 4 : The server is running on 8080 as mentioned in config file. URL : http://localhost:8080/
step 5 : Go to postman. 
          5.1.Switch GET method , use the endpoint "/bookings" to get all customer Bookings.
          5.2.Switch POST method , use the endpoint "/bookings" to create a customer Bookings.
          5.3.Switch PUT method , use the endpoint "/bookings/id" to update existed customer Bookings.
          5.4.Switch DELETE method , use the endpoint "/bookings/id" to delete a customer Bookings.
          5.5. To get a specfic Booking details , use the endpoint /bookings/id to get specific customer Booking details.



Sample Customer Data:
{
        "customer_name": "Ragul",
        "booking_date": "2022/09/20",
        "booking_time": "'8:00:00PM",
        "total_amount": 50000,
        "status": "Failed",
        "payment_method": "Card",
        "duration_minutes": "5"
    },