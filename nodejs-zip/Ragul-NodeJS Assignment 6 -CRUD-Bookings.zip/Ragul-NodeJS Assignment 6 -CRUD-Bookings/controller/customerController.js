let db=require("../config/db.js");
const dbModel= require('../models/bookingModel')
const CreateCustomers=async (req,res)=>{
    try{

    let newData=await dbModel.create(req.body);
    res.status(201).json({
        message:"Customer Created",newData
    });
    console.log("Customer Created");
    }
    catch(error){
        console.log("400 Error",error.message);
        res.status(400).send("Customer not created",error.message);
    }
}


const getAllCustomers=async (req,res)=>{
    try{
        let newData=await dbModel.find({});
        res.status(200).send(newData);
        console.log("Got all customers");
    }
    catch(error){
        console.log("404 Error",error.message);
        res.status(404).json("GetUsers not found",error.message)
    }
}

const getCustomerById=async(req,res)=>{
    try{

        let {id}=req.params;
        let newData=await dbModel.findById(id);

        res.status(200).json({message:"GetUserById is found",newData});
    }
    catch(error){
        res.status(400).json("GetUserById not found",error.message);
    }

    }
const updateCustomerById=async(req,res)=>{
        try{
    
            let {id}=req.params;
            let data=req.body;
            let newData=await dbModel.findByIdAndUpdate(id,data);
            let updatedData=await dbModel.findById(id);
    
            res.status(200).json({
                message:"Customer updated...",updatedData
            });
        }
        catch(error){
            res.status(400).json("UpdatingCustomers not found",error.message);
        }
    
        }
const deleteCustomerById=async(req,res)=>{
            try{
        
                let {id}=req.params;
                let newData=await dbModel.findByIdAndDelete(id);
                res.status(200).send("Customers Deleted Successfully");
            } 
            catch(error){
                res.status(400).json("DeletingCustomers not found",error.message);
            }
        
            }
module.exports={
    CreateCustomers,
    getAllCustomers,
    getCustomerById,
    updateCustomerById,
    deleteCustomerById

};



