const express=require("express");
const dotenv=require("dotenv");
let app=express();

require("colors")
const routes=require("./routes/routes.js")
const db=require("./config/db");
dotenv.config({path:"./config/config.env"});
app.use("/",routes);
db(app);

module.exports=app;




