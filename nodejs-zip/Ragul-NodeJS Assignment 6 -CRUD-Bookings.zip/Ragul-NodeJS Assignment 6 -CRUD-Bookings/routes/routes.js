

const express=require('express');
const app=express();
const router=express.Router();
router.use(express.json());
const customer=require("../controller/customerController");
router.post("/bookings",customer.CreateCustomers);
router.get("/bookings",customer.getAllCustomers);
router.get("/bookings/:id",customer.getCustomerById);
router.put("/bookings/:id",customer.updateCustomerById);
router.delete("/bookings/:id",customer.deleteCustomerById); 
module.exports=router;




