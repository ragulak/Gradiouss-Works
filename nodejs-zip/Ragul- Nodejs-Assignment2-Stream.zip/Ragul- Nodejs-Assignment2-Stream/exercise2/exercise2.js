let fs=require("fs");
let readd=fs.createReadStream("./lib/sample.exe");
let writee=fs.createWriteStream("./lib/gradious-assignment.exe");

readd.on("data",(data)=>{
    writee.write(data);


});
console.log("file written successfully");
