let fs=require("fs");
let http=require("http");
let server=http.createServer();

let hostname="localhost";
let portnumber=8080;

server.on("request",(req,res)=>{
    if(req.url==="/home"){
    fs.readFile("../lib/home.html","utf-8",(error,data)=>{
        if(error){
            console.error(error);
        }
        else{
            res.end(data);

        }
    });
}
    if(req.url==="/about"){
    fs.readFile("../lib/about.html","utf-8",(error,data)=>{
        if(error){
            console.error(error);
        }
        else{
            res.end(data);

        }
    });
}

    if(req.url==="/contact"){
    fs.readFile("../lib/contact.html","utf-8",(error,data)=>{
        if(error){
            console.error(error);
        }
        else{
            res.end(data);

        }
    });
}

});

server.listen(portnumber,hostname,()=>{
    console.log(`Hit the server using http://${hostname}:${portnumber}`)



});                            