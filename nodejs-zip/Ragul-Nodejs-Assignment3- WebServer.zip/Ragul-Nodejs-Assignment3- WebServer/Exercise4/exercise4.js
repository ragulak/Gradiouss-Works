let express=require("express");
let e=express();
e.use(express.static("../public"));
e.listen(8080);