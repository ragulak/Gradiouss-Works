let fs=require("fs");
let http=require("http");
let server=http.createServer();

let hostname="localhost";
let portnumber=8080;

server.on("request",(req,res)=>{
    res.setHeader("Content-type","text/HTML");
    fs.readFile("../lib/users.txt","utf-8",(error,data)=>{
        if(error){
            console.error(error);
        }
        else{
            let splitdata=data.toString().split("|").toString().split("\r\n").toString().split(",");
            // console.log(splitdata);

            let table=`<table border><tr><th>Name</th><th>Age</th><th>Gender</th><th>City</th></tr>`;
            let tabledata="";
            // console.log(splitdata[4]);
            for(let i=4;i<splitdata.length;i=i+4){
                tabledata+=`<tr><td>${splitdata[i]}</td><td>${splitdata[i+1]}</td><td>${splitdata[i+2]}</td><td>${splitdata[i+3]}</td></tr>`
            }
          let finaldata=`${table} ${tabledata} </table>`;
          res.writeHead(200);

          res.end(finaldata);
        }
    });

}
);
server.listen(portnumber,hostname,()=>{
    console.log(`Hit the server using http://${hostname}:${portnumber}/`)


});
