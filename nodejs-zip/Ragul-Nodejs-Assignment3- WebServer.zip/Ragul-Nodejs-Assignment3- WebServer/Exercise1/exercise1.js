let fs=require("fs");
let http=require("http");
let server=http.createServer();

let hostname="localhost";
let portnumber=8080;

server.on("request",(req,res)=>{
    if(req.url==="/"  || req.url==="/index"){
    fs.readFile("../lib/index.html","utf-8",(error,data)=>{
        if(error){
            console.error(error);
        }
        else{
           res.writeHead(200);

        res.end(data);
           
            console.log("content loaded...");
        }
    });

    }
}
);
server.listen(portnumber,hostname,()=>{
    console.log(`Hit the server using http://${hostname}:${portnumber}/`)


});

