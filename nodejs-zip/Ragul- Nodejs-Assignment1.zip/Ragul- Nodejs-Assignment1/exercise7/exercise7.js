let xlsx=require("xlsx");
let xcel=xlsx.readFile("./lib/marks.xlsx");
let xcelSheets=xcel.SheetNames[0];

let xcelSheetsData=xcel.Sheets[xcelSheets];
console.log(xlsx.utils.sheet_to_json(xcelSheetsData));