let fs=require("fs");
let moment=require("moment");
function getFileContent(file){

    fs.readFile(file,"utf-8",function(err,data){
        if(err){

            console.log("file not found");
        }
        else{
            let log=data.split("\r\n");
            let datee=moment().format("DD-MM-YYYY, h:mm:ss");

            var print="";
            for(let i=0;i<log.length;i++){

                print+=datee+"  "+log[i]+"\n";
            }
            console.log(print);
        }
    });}


getFileContent("./lib/debug.log");