var fs=require("fs");
function getFileContent(sourcefile,newfile){
    fs.copyFile(sourcefile,newfile,function(err){

        if(err){
            console.log("file not found");
        }
        else{
            console.log("file copied successfully")
        }
    })

}
getFileContent("./lib/sourcefile.txt","./lib/newfile.txt");