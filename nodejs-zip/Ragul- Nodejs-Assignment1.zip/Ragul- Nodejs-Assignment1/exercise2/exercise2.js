var fs=require("fs"); 

function getFileContent(file){

  let alpha="1234567890abcdefghijklmnopqrstuvwxyzAFGDHJKLQWERTYUIOPZXCVBNM";
  let length=alpha.length;
  var str="";
    

    for(let i=0;i<100;i++){
   
       for(let j=0;j<10;j++){
           
            str+=alpha.charAt(Math.random()*length);
         }
    str+="\n";
    
        }

fs.writeFile(file,str,function(err){
 if(err){
    console.log("file not found");
  }
 else{
    console.log("file written"); 

  }


});
}

getFileContent("./lib/random-words.txt");