var fs=require("fs");
var str="";
var jsonstr="";
function getFileContent(file){
    fs.readFile(file,'utf-8',function(err,data){

        if(err){
            console.log("file not found");
        }
        else{
            str=data;
            jsonstr=(str.toString().split("|").toString().split("\r\n").toString().split(","));
        }



// console.log(jsonstr);
let length=jsonstr.length;
let jstr=[];
for(let i=0;i<length;i=i+4){
 jstr+=(`{Name:${jsonstr[i]},Age:${jsonstr[i+1]},Gender:${jsonstr[i+2]},City:${jsonstr[i+3]}},\n`);

}
console.log(jstr);
});

}
getFileContent("./lib/readfile.txt");