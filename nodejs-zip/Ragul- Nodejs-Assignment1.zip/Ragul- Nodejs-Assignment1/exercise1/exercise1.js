let fs=require('fs'); 
function getFileContent(file){
    fs.readFile(file,'utf-8',function(err,data){
        
        if(err){
            console.log("file not found");
        }
        
        else{
            console.log(data); 
        }
    });
}

getFileContent("./lib/readme.txt");

getFileContent("./lib/index.html");

getFileContent("./lib/students.csv");
