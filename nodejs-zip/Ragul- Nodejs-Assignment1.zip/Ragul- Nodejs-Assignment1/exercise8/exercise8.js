let fs=require("fs");
let xcel=require('json2xls');
var obj=[{"Name":"Logesh" ,"Age": 32  ,"Gender":  "Male" ,"City":  "Chennai"},
{"Name":"Balaji" ,"Age": 23  ,"Gender":  "Male"  ,"City":  "Hyderabad"},
{"Name":"Sri" ,"Age": 25  ,"Gender":  "Male"  ,"City":  "Kolkata"},
{"Name":"Mani" ,"Age": 24 ,"Gender":  "Male"  ,"City":  "Chennai"},
{"Name":"Shankar" ,"Age": 39  ,"Gender":  "Male"  ,"City":  "Kolkata"},
{"Name":"Thanos" ,"Age": 33,"Gender":  "Male"  ,"City":  "Hyderabad"}
];

function getFileContent(file){
 let xceldata=xcel(obj);

    fs.writeFile(file,xceldata,'binary',function(err){
        if(err){

            console.log("file not converted");
        }
        else{
            console.log("file converted");
        }
    })



}

getFileContent("./lib/marks.xlsx");

