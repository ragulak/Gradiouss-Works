var fs=require("fs");
var obj=[{"Name":"Logesh" ,"Age": 32  ,"Gender":  "Male" ,"City":  "Chennai"},
{"Name":"Balaji" ,"Age": 23  ,"Gender":  "Male"  ,"City":  "Hyderabad"},
{"Name":"Sri" ,"Age": 25  ,"Gender":  "Male"  ,"City":  "Kolkata"},
{"Name":"Mani" ,"Age": 24 ,"Gender":  "Male"  ,"City":  "Chennai"},
{"Name":"Shankar" ,"Age": 39  ,"Gender":  "Male"  ,"City":  "Kolkata"},
{"Name":"Thanos" ,"Age": 33,"Gender":  "Male"  ,"City":  "Hyderabad"}
];
function getFileContent(file){
//  let jsonobj=JSON.stringify(obj);
//  console.log(jsonobj);

let res="";
for(let i of obj){
//   console.log(i.Name);
    
  res+=`${i.Name}  |   ${i.Age}  |    ${i.Gender } |   ${i.City}\n`;
}

fs.writeFile(file,res,function(err){
    if(err){

        console.log("file not found");
    }

    else{
        console.log("file written successfully");
    }
});


}

getFileContent("./lib/users-info.txt");