function validate() {
 let fname=document.getElementById("fnamev").value;
 let lname=document.getElementById("lnamev").value;
 let email=document.getElementById("emailv").value;
 let phone=document.getElementById("phonev").value;
 let radio=document.querySelector('input[name="Gender"]:checked').value;
 let city=document.getElementById("cityv").value;
 let applied=document.getElementById("appliedv").value;
 let earliest=document.getElementById("earliestv").value;
 let prefered=document.getElementById("preferedv").value;
 let time=document.querySelector('input[name="time"]:checked').value;



var regNamee  = /^[A-Za-z][A-Za-z_]{0,29}$/;

   
 var regPhone =  /^\+91\d{10}$/;

    var regEmailid = /^[a-zA-Z0-9+_.-]+@[a-zA-Z0-9.-]+$/;

    var regPosition  = /^[A-Za-z][A-Za-z_ ]{0,29}$/;
 if(regNamee.test(fname) && regPhone.test(phone) && regEmailid.test(email) && regPosition.test(applied))

{
    localStorage.setItem("First name",fname);
 localStorage.setItem("Last name",lname);
 localStorage.setItem("Email id",email);
 localStorage.setItem("Phone number",phone);
 localStorage.setItem("Gender",radio);
 localStorage.setItem("City",city);
 localStorage.setItem("Applied position",applied);
 localStorage.setItem("Earliest date",earliest);
 localStorage.setItem("Prefered date",prefered);
 localStorage.setItem("Time",time);  
 

alert("You have successfully applied full-stack developer job");
 }
 else{
   alert("invalid credentials");
}
}
function onreload(){
    document.getElementById( "fnamev").value=localStorage.getItem("First name");
    document.getElementById( "lnamev").value=localStorage.getItem("Last name");
    document.getElementById( "emailv").value=localStorage.getItem("Email id");
    document.getElementById( "phonev").value=localStorage.getItem("Phone number");
    document.getElementById( "cityv").value=localStorage.getItem("City");
    document.getElementById( "appliedv").value=localStorage.getItem("Applied position");
    document.getElementById( "earliestv").value=localStorage.getItem("Earliest date");
    document.getElementById( "preferedv").value=localStorage.getItem("Prefered date");
   
    let radio=localStorage.getItem("Gender");

    const gender=document.querySelector(`input[type="radio"][value="${radio}"]`);
if(gender){
   gender.checked=true;

}

let timee=localStorage.getItem("Time");

const timeee=document.querySelector(`input[type="radio"][value="${timee}"]`);
if(timeee){
timeee.checked=true;

}

}

window.onload=onreload;


