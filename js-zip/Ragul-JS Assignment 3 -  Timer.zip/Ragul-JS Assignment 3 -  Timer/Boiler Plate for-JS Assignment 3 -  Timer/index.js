function setTimer(){
    var days=document.getElementById("daysIn").value;
    var hours=document.getElementById("hoursIn").value;
    var minutes=document.getElementById("minsIn").value;
    var seconds=document.getElementById("secsIn").value;

    var totalSec=(Number(days)*24*60*60)+(Number(hours)*60*60)+(Number(minutes)*60)+ (Number(seconds));
var dayToSec=Math.floor(totalSec/(86400));

var hourToSec=Math.floor((totalSec%86400)/(60*60));
var minToSec=Math.floor((totalSec%3600)/(60));
var secToSec=Math.floor(totalSec%60);  



document.getElementById("days").innerHTML=dayToSec;
document.getElementById("hours").innerHTML=hourToSec;
document.getElementById("mins").innerHTML=minToSec;
document.getElementById("secs").innerHTML=secToSec;


document.getElementById('daysIn').value=0;
document.getElementById('hoursIn').value=0;
document.getElementById('minsIn').value=0;


document.getElementById('secsIn').value=0;



// document.getElementById("days").innerHTML=days;
// document.getElementById("hours").innerHTML=hours;
// document.getElementById("mins").innerHTML=minutes;
// document.getElementById("secs").innerHTML=seconds;




}

function reset(){ 
    
    stop();

document.getElementById("days").innerHTML="00";
document.getElementById("hours").innerHTML="00";
document.getElementById("mins").innerHTML="00";
document.getElementById("secs").innerHTML="00";


}

var interval;
function start(){


    var dayss=document.getElementById("days").innerHTML;
    var hourss=document.getElementById("hours").innerHTML;
    var minss=document.getElementById("mins").innerHTML;
    var secss=document.getElementById("secs").innerHTML;

    interval=setInterval(display,1000);
    function display(){

        if(secss>0){
            secss--;

            document.getElementById("secs").innerHTML=secss;
        }
        else if( secss==0   &&   minss>0  ){
            minss--;

            document.getElementById("mins").innerHTML=minss;
            secss=60;
        }

        else if( secss==0   &&   minss==0  && hourss>0 ){
            hourss--;

            document.getElementById("hours").innerHTML=hourss;
            minss=60;
        }

        else if( secss==0   &&   minss==0 && hourss==0 && dayss>0 ){
        
            dayss--;

            document.getElementById("days").innerHTML=dayss;
            hourss=24;
        }



    }
  
}
function stop(){
    clearInterval(interval);
}













