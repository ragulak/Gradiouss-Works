var users="";
function displayy(){
    var userPlus = document.getElementById("addUser");
    var addModal = document.getElementById("modalAddUser");
    var editModal=document.getElementById("editUser");
    
    userPlus.addEventListener("click", () => {
        addModal.style.display = "block";
    });
    window.addEventListener("click",(event)=>{
        if(event.target==editModal){

            editModal.style.display="none";
        }
    });
    window.addEventListener("click", (event)=> {
        if (event.target == addModal) {
          addModal.style.display = "none";
        }
    });
    let view=` <tr id="tableHeadings">
    <th class="name">Name</th>
    <th class="age">Age</th>
    <th class="state">State</th>
    <th class="functions">Functions</th>
</tr>`
var req=new XMLHttpRequest();
req.open("GET","https://650459bac8869921ae24e804.mockapi.io/users",true);
req.send();
req.onreadystatechange=function(){
if(req.readyState===4){
if(req.status===200){
//  console.log(JSON.parse(req.responseText));

 users=JSON.parse(req.responseText);
for(let key in users){
 
view+=` <tr class="user" id="user1">
 <td id="namee" class="name">${users[key].name}</td>
 <td id="agee" class="age">${users[key].age}</td>
 <td id="statee" class="state">${users[key].state}</td>
 <td class="functions">
     <button class="edit" onclick="editUser(${users[key].id});" type="button" id="1"><i class="fa-solid fa-pen-clip"></i></button><button class="deleteB" onclick="deleteUser(${users[key].id});"type="button" id="1"><i class="fa-solid fa-trash-can"></i></button>
 </td>
</tr>

`
//console.log(users[key].name);


document.getElementById("table").innerHTML=view;

}
}
}

};
}
function editUser(ind){
   

let     vieww=`   <div class="modal-dialog">
<div class="modal-content">
  <div class="modal-body">
      <form id="editUserForm">
          <input type="text" id="inputNamenew" placeholder="Name">
          <input type="number" id="inputAgenew" placeholder="Age" max="100" min="0">
          <select id="inputStatenew">
              <option disabled="" selected="">State</option>
              <option>Andaman and Nicobar Islands</option>
              <option>Andhra Pradesh</option>
              <option>Arunachal Pradesh</option>
              <option>Assam</option>
              <option>Bihar</option>
              <option>Chandigarh</option>
              <option>Chhattisgarh</option>
              <option>Dadra and Nagar Haveli and Daman &amp; Diu</option>
              <option>Delhi</option>
              <option>Goa</option>
              <option>Gujarat</option>
              <option>Haryana</option>
              <option>Himachal Pradesh</option>
              <option>Jammu &amp; Kashimr</option>
              <option>Jharkand</option>
              <option>Karnataka</option>
              <option>Kerala</option>
              <option>Ladakh</option>
              <option>Lakshadweep</option>
              <option>Madhya Pradesh</option>
              <option>Maharashtra</option>
              <option>Manipur</option>
              <option>Meghalaya</option>
              <option>Mizoram</option>
              <option>Nagaland</option>
              <option>Odisha</option>
              <option>Puducherry</option>
              <option>Punjab</option>
              <option>Rajasthan</option>
              <option>Sikkim</option>
              <option>Tamil Nadu</option>
              <option>Telanagana</option>
              <option>Tripura</option>
              <option>Uttar Pradesh</option>
              <option>Uttarakhand</option>
              <option>West Bengal</option>
          </select>
          <button type="button" class="btn btn-primary" onclick="editUser1(${ind})" id="editUserButton">Edit User</button>
      </form>
  </div>
</div>
</div>
`



document.getElementById("editUser").innerHTML=vieww;
var editModal1 = document.getElementById("editUser");
editModal1.style.display = "block";


// document.getElementById("addUserForm").style.display="none";
document.getElementById("editUser").style.display="block";



let objjj=users.findIndex((obj)=>obj.id==ind);

    document.getElementById("inputNamenew").value=users[objjj].name;
    document.getElementById("inputAgenew").value=users[objjj].age;
    document.getElementById("inputStatenew").value=users[objjj].state;
    // console.log(users[objjj].name);
   }

function editUser1(editid){
    document.getElementById("editUser").style.display="none";
    var editname=document.getElementById("inputNamenew").value;
    var editage=document.getElementById("inputAgenew").value;
    var editstate=document.getElementById("inputStatenew").value;
    let editt=JSON.stringify({
        "name":editname,
        "age":editage,
        "state":editstate
 });
// console.log(editt);
//  console.log(editname);
    var req=new XMLHttpRequest();
    req.open("PUT",`https://650459bac8869921ae24e804.mockapi.io/users/${editid}`);
    req.setRequestHeader("content-type","application/json");
    req.send(editt);

    req.onreadystatechange=function(){
        if(req.readyState==4){
            if(req.status==200){
                 console.log("sdfgsafdbs");
                }
            displayy();
        }
    }}
function deleteUser(deleted){
let deletee=`<div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabel">Confirm the User</h5>
              <button type="button" class="close deleteCancel" data-bs-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">×</span>
              </button>
            </div>
            <div class="modal-body" id="deletebtn">
             
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-danger confirmDelete" onclick="confirmDelete1(${deleted})" data-bs-dismiss="modal">Delete</button>
              <button type="button" class="btn btn-secondary deleteCancel" data-bs-dismiss="modal">Cancel</button>
            </div>
          </div>
        </div>`

document.getElementById("deleteModal").innerHTML=deletee;
    var modal = document.getElementById("deleteModal");
    modal.classList.add("show");
    modal.style.display = "block";
    var cancelDelete=document.querySelectorAll(".deleteCancel");
    cancelDelete.forEach((btn)=>{
        btn.addEventListener("click", ()=>{
            modal.style.display = "none";
        });
    });
    
    var confirmDelete = document.querySelector(".confirmDelete");
    confirmDelete.addEventListener("click", ()=>{
        modal.style.display = "none";
  });
    const index = users.findIndex((obj)=>obj.id==deleted);
    let deletename=` <h5><b>Deleting: ${users[index].name}<span id="userDeleted"></span></b></h5>`
    document.getElementById("deletebtn").innerHTML=deletename;

}
function confirmDelete1(idd){
    let del=new XMLHttpRequest();

del.open("DELETE","https://650459bac8869921ae24e804.mockapi.io/users/"+idd,true);
del.send();
del.onreadystatechange=function(){
    if(del.readyState===4){
        if(del.status===200){
            console.log(JSON.parse(del.responseText));



        }displayy();}
    };
}
function addUserr(){
document.getElementById("modalAddUser").style.display="none";
let nameee=document.getElementById("inputName").value;
let ageee=document.getElementById("inputAge").value;
let inputStateee=document.getElementById("inputState").value;
console.log(nameee);
// let len=users.length+1;
let addd= JSON.stringify({           
    "name": nameee,
    "age": ageee,
    "state": inputStateee,

});
// let a=JSON.stringify("addd");
let ad=new XMLHttpRequest();
ad.open("POST","https://650459bac8869921ae24e804.mockapi.io/users",true);
ad.setRequestHeader("content-type","application/json");
ad.send(addd);
ad.onreadystatechange=function(){
    if(ad.readyState===4){
        if(ad.status===200){
            
 }
 reset();
 displayy();

}};
}

function reset(){
    document.getElementById("inputName").value="";
document.getElementById("inputAge").value="";
document.getElementById("inputState").selectedIndex=0;
}

// document.getElementById("inputName").value="";
// document.getElementById("inputAge").value="";
// document.getElementById("inputState").selectIndex=3;

window.onload=displayy;
