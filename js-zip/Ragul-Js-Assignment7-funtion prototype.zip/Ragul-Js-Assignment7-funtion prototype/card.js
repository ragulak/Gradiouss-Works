//Base Class-Card
function Card(cardNumber,cardHolderName,cardName,cardType,cardBalanceamt){
    this.cardNumber=cardNumber;
    this.cardHolderName=cardHolderName;

    this.cardName=cardName;

    this.cardType=cardType;
    this.cardBalanceamt=cardBalanceamt;

}
//makePayment method to calculate the amount
Card.prototype.makePayment=function(amount){
    this.amount=amount;
    if(this.cardBalanceamt>=amount){
          console.log(`An amount of Rs. ${amount} is debited from your account no ${this.cardNumber} at ${new Date()}`);
          this.cardBalanceamt -= amount;
    }
    else{
        console.log(`Insufficient Balance`+"\n");
            this.cardBalanceamt -= amount;
}


};


//displaydetails to display all card details
Card.prototype.displayDetails=function(){
     console.log(`Card Name:  ${this.cardName}`);
     console.log(`Card Type : ${this.cardType}`);

     console.log(`Card Holder : ${this.cardHolderName}`);
     console.log(`Card number : ${this.cardNumber}`);

     let oldBalanceamt= this.cardBalanceamt + this.amount;
     console.log(`Old Balance : ${oldBalanceamt}`);

     console.log(`Available balance :${this.cardBalanceamt}`+"\n");

}
//constructor function CreditCard

function CreditCard(cardNumber,cardHolderName,cardName,cardType,cardBalanceamt){
    Card.call(this,cardNumber,cardHolderName,cardName,cardType,cardBalanceamt)
    // this.cardType=cardType;
}
//

CreditCard.prototype=Object.create(Card.prototype);
CreditCard.prototype.construtor=CreditCard;  

function DebitCard(cardNumber,cardHolderName,cardName,cardType,cardBalanceamt){
    Card.call(this,cardNumber,cardHolderName,cardName,cardType,cardBalanceamt)
    // this.cardType=cardType;
}

CreditCard.prototype=Object.create(Card.prototype);
CreditCard.prototype.construtor=DebitCard;  



var creditCard=new CreditCard(1234567891234567,"Ragul AK","Rupay","Credit_card",9000)

creditCard.makePayment(3000);
if(creditCard.cardBalanceamt>= 0){

    creditCard.displayDetails();
}
var debitCard=new CreditCard(98765432198765432,"Ragul AK","Visa","Debit_card",6000)
debitCard.makePayment(2000);


if(debitCard.cardBalanceamt >= 0){

    debitCard.displayDetails();
}