Step 1. Create a constructor function called Card with cardNumber, cardName, cardHolderName, cardType and cardBalanceamt properties.
Step 2. Create a method with Card prototype called makePayment which deducts the given amount from the cardBalanceamt property if it is less than or equal to the cardBalanceamt and print the details.
Step 3. Create a method with Card prototype called displayDetails which displays the card details including card details,old balance, available balance.
Step 4. Define a constructor function called creditCard which inherits from the Card constructor using call() method and sets its own prototype to be an object created from the Card prototype.
Step 5. Set the constructor property of the creditCard prototype to be the creditCard constructor itself.
Step 6. Define a constructor function called debitCard which also inherits from the Card constructor using call() and sets its own prototype to be an object created from the Card prototype.
Step 7. Set the constructor property of the debitCard prototype to be the debitCard constructor itself.
Step 8. Create instances of both creditCard and debitCard.
Step 9. Call the makePayment() method on both instances to deduct amounts from their respective balances.
Step 10.Check if the balance is greater than or equal to 0 and call the displayDetails() method on both instances to log their respective card details.