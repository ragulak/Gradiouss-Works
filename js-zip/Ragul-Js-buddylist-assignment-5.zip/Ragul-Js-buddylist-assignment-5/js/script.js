let status = {
	1: "one",
	2: "two",
	3: "three",
	4: "four",
};




let users_json = [{
		userId: 1,
		name: "Jon Snow",
		profilePicture:
			"https://cg0.cgsociety.org/uploads/images/original/hosseindiba-jon-snow-1-b968195d-au6q.jpeg",
		statusMessage: "We become what we think about!",
		presence: 1,
	},
	{
		userId: 2,
		name: "Daenerys Targaryen",
		profilePicture:
			"https://preview.redd.it/hlxen8gtwpm01.jpg?width=640&crop=smart&auto=webp&v=enabled&s=a3c43bcbfc1db31d542ef67071559264358b3d2b",
		statusMessage: "A positive mindset brings positivethings.",
		presence: 3,
	},
	{
		userId: 3,
		name: "Tyrion Lannister",
		profilePicture:
			"https://mir-s3-cdn-cf.behance.net/project_modules/fs/6a3f5237411193.573f25019c8bf.jpg",
		statusMessage: "One small positive thought can change your whole day",
		presence: 3,
	},
	{
		userId: 4,
		name: "Jaime Lannister",
		profilePicture:
			"https://i.pinimg.com/originals/b8/16/d2/b816d2a1df83966cf8f6de301fcfe9ef.jpg",
		statusMessage: "I am a rockstar",
		presence: 1,
	},
	{
		userId: 5,
		name: "Arya Stark",
		profilePicture:
			"https://64.media.tumblr.com/21de4501827aba1c6463ce2ae6a36780/tumblr_ps5le9xxRb1w9a5vgo1_1280.jpg",
		statusMessage: "I am using Gradious messenger",
		presence: 4,
}];


function display(){
var users=`
<nav class="nav-bar">
<div class="logo">
        <p>Buddy List</p>
</div>
<div class="links">
<button onclick="visibileUserForm()"><i class="bi bi-person-plus-fill"></i></button>
</div>
</nav>
<div class="container-1">
        <div id='root' class="users-container">`

for(let key in users_json){

	console.log(key);
	users+=`<div class="user">
	<div class="img-container">
		<img src=${users_json[key].profilePicture} class='user-image ${status[users_json[key].presence]}' alt="user image" />
	</div>
	<div class="user-detail">
	<p class="user-name">${users_json[key].name}</p>
	<p class="user-message">${users_json[key].statusMessage}</p>
	</div>
	<div class='three-btn'>
		<div class="dropdown">
			<a class="" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false"><i class="bi bi-three-dots-vertical"></i></a>
			<ul class="dropdown-menu">
				<li><button id='USR0001' onclick='deleteItem(${key})'class="dropdown-item ">Delete</button></li>
				<li><button  id='update-USR0001' onclick='showForm(${key})'class="dropdown-item ">Update</button></li>
			</ul>
		</div>
	</div>
</div>`
}
 users+=`</div>
 <form class="addUserForm">
            <div class='form'>
                <div class="input">
                    <input type="text" name="" id="name" placeholder="Name">
                </div>
                <div class="input">
                    <input type="text" name="" id="statusMessage" placeholder="Status Message">
                </div>
                <div class="input">
                    <input type="text" name="" id="profilePicLink" placeholder="Profile Picture Link">
                </div>
                <div class="input">
                    <select name="" id="presence">
                        <option value="1">Availble</option>
                        <option value="2">Busy</option>
                        <option value="3">idle</option>
                        <option value="4">Not loggedin</option>
                    </select>
                </div>
                <div>
                    <button class="btn" onclick="addUser()">Add User</button>
                </div>
            </div>
        </form>
<form id='updateUserForm'>
		
	</form>
		</div>
 `
 


document.getElementById("buddy").innerHTML=users;
}

function visibileUserForm(){
	let stylee=document.querySelector(".addUserForm");
	stylee.classList.toggle("mystyle");

}
function deleteItem(deleted){

	console.log(deleted);

    delete users_json[deleted];
	display();
}
function addUser(){    
	event.preventDefault();

// console.log("sdfhfd");

let namee=document.getElementById("name").value;
	let statusMessagee=document.getElementById("statusMessage").value;
	let picturee=document.getElementById("profilePicLink").value;
	let presencee=document.getElementById("presence").value;
  
	let lengthh=users_json.length+1;
console.log(namee,presencee);
users_json.unshift({
		userId: lengthh,
		name: namee,
		profilePicture:picturee,
		statusMessage: statusMessagee,
		presence: presencee,
})
console.log(users_json);

display();

}




function showForm(updid){


	let ele=document.querySelector(".addUserForm");
	let el=document.querySelector(".form");

	ele.style.display="none";
	el.style.display="block";

//  let updatee=document.querySelector(".add");
//  updatee.classList.toggle("mystyle2");


let upt=`<div class='form'>
<div class="input">
	<input type="text" name="" id="name1" placeholder="Name">
</div>
<div class="input">
	<input type="text" name="" id="statusMessage1" placeholder="Status Message">
</div>
<div class="input">
	<input type="text" name="" id="profilePicLink1" placeholder="Profile Picture Link">
</div>
<div class="input">
	<select name="" id="presence1">
		<option value="1">Availble</option>
		<option value="2">Busy</option>
		<option value="3">idle</option>
		<option value="4">Not loggedin</option>
	</select>
</div>
<div>
	<button class="btn" onclick="updateItem(${updid})">Update User</button>
</div>
</div>`
 document.getElementById('updateUserForm').innerHTML=upt;

 document.getElementById("name1").value=users_json[updid].name;
 document.getElementById("statusMessage1").value=users_json[updid].statusMessage;
 document.getElementById("profilePicLink1").value=users_json[updid].profilePicture;
 document.getElementById("presence1").value=users_json[updid].presence;
 
}

function updateItem(updateId){
	// let x= users_json.findIndex(x=>x.userId==update)
    let nameee=document.getElementById("name1").value;
	let statusMessageee=document.getElementById("statusMessage1").value;
	let pictureee=document.getElementById("profilePicLink1").value;
	let presenceee=document.getElementById("presence1").value;


	

	users_json[updateId].name=nameee;
	users_json[updateId].statusMessage=statusMessageee;
	users_json[updateId].profilePicture=pictureee;
	users_json[updateId].presence=presenceee;
  
	display();




	
}

// if(updid==(users_json[updid].userId-1)){
	// users_json[updid].name="kee";
	// 	users_json[updid].statusMessage=statusMessageee;
	// 	users_json[updid].profilePicture=pictureee;
	// 	users_json[updid].presence=presenceee;
	// 	
	
	
window.onload=display;